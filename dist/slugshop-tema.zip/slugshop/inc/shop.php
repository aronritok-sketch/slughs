<?php
/**
 * WooCommerce: klasszikus (shortcode-os) kosár, pénztár és fiók; a kinézet a téma CSS-éből.
 *
 * - A WooCommerce saját CSS-e csak a kosár / pénztár / fiók oldalon töltődik (ott a szerkezetét használjuk).
 * - Kosárba tétel AJAX-szal a kártyákról és a termékoldalról (JS nélkül is működik: ?add-to-cart= / POST).
 * - Pénztár: magyar sorrend (vezetéknév elöl), kötelező telefon, nem kötelező adószám – a Számlázz.hu bővítmény
 *   kulcsába is beírva (DONTESEK 2026-10-08, Mandala: különben a számlán nincs adószám).
 */

defined('ABSPATH') || exit;

add_filter('woocommerce_enqueue_styles', function ($styles) {
    if (function_exists('is_cart') && (is_cart() || is_checkout() || is_account_page())) {
        unset($styles['woocommerce-smallscreen']);
        return $styles;
    }
    return [];
});

// A WooCommerce blokkjainak stílusai nem kellenek (klasszikus oldalak).
add_action('wp_enqueue_scripts', function () {
    foreach (['wc-blocks-style', 'wc-blocks-vendors-style', 'wc-block-style'] as $h) {
        wp_dequeue_style($h);
    }
}, 100);

// A WooCommerce saját morzsamenüje és oldalsávja nem kell (a téma rajzolja).
add_action('init', function () {
    remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
    remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
});

/** A fejléc kosár-számlálója a WooCommerce AJAX-válaszában is (fragments). */
add_filter('woocommerce_add_to_cart_fragments', function (array $fragments): array {
    $n = slugshop_cart_count();
    $fragments['span.cart-count'] = '<span class="cart-count" data-cart-count data-n="' . $n . '">' . $n . '</span>';
    return $fragments;
});

/** Pénztár: magyar sorrend, kötelező telefon, adószám. */
add_filter('woocommerce_billing_fields', function (array $f): array {
    if (isset($f['billing_last_name'], $f['billing_first_name'])) {
        $f['billing_last_name']['priority'] = 10;
        $f['billing_last_name']['class'] = ['form-row-first'];
        $f['billing_first_name']['priority'] = 20;
        $f['billing_first_name']['class'] = ['form-row-last'];
    }
    if (isset($f['billing_phone'])) {
        $f['billing_phone']['required'] = true;
        $f['billing_phone']['priority'] = 25;
        $f['billing_phone']['placeholder'] = '+36 30 123 4567';
    }
    if (isset($f['billing_email'])) {
        $f['billing_email']['priority'] = 26;
    }
    // Cégnév: a Számlázz.hu bővítmény ehhez köti az adószámot (ha kitöltik, az adószám kötelező).
    $f['billing_company'] = array_merge($f['billing_company'] ?? [], [
        'label' => 'Cégnév', 'required' => false, 'class' => ['form-row-wide'], 'priority' => 30, 'autocomplete' => 'organization',
    ]);
    // Saját adószám mező csak akkor, ha a Számlázz.hu bővítmény nem ad sajátot (különben kétszer szerepelne).
    if (!slugshop_szamlazz_vat_field()) {
        $f['billing_tax_number'] = [
            'label' => 'Adószám', 'description' => 'Csak cégnek, ha a számlára kell.', 'required' => false, 'class' => ['form-row-wide'], 'priority' => 31,
            'placeholder' => '12345678-1-12', 'autocomplete' => 'off',
        ];
    }
    return $f;
});

/** A Számlázz.hu bővítmény (Integration for Szamlazz.hu & WooCommerce) saját adószám mezője (wc_szamlazz_adoszam). */
function slugshop_szamlazz_vat_field(): bool
{
    return class_exists('WC_Szamlazz') || defined('WC_SZAMLAZZ_PLUGIN_FILE') || function_exists('WC_Szamlazz');
}
/** A cégnév mező a WooCommerce beállításától függetlenül látszik (nem kötelező). */
add_filter('pre_option_woocommerce_checkout_company_field', fn() => 'optional');
add_filter('woocommerce_shipping_fields', function (array $f): array {
    if (isset($f['shipping_last_name'], $f['shipping_first_name'])) {
        $f['shipping_last_name']['priority'] = 10;
        $f['shipping_last_name']['class'] = ['form-row-first'];
        $f['shipping_first_name']['priority'] = 20;
        $f['shipping_first_name']['class'] = ['form-row-last'];
    }
    return $f;
});
/** Magyarországon a megye nem kell a címhez (a WooCommerce listát adna hozzá). */
add_filter('woocommerce_get_country_locale', function (array $locale): array {
    $locale['HU']['state'] = ['required' => false, 'hidden' => true];
    return $locale;
});
/**
 * A WooCommerce 11 országbeállítása a telefonnak 100-as sorrendet ad, és a pénztár JS-e (address-i18n) ez alapján
 * a mezőt a cím alá rendezi: a név és az e-mail közé tesszük, a cégnevet az adószám elé.
 */
add_filter('woocommerce_get_country_locale_default', function (array $d): array {
    $d['phone'] = array_merge($d['phone'] ?? [], ['priority' => 25]);
    $d['company'] = array_merge($d['company'] ?? [], ['priority' => 30, 'required' => false, 'hidden' => false]);
    return $d;
});
add_filter('woocommerce_get_country_locale', function (array $locale): array {
    foreach ($locale as $cc => $fields) {
        if (isset($fields['phone'])) {
            $locale[$cc]['phone']['priority'] = 25;
        }
        if (isset($fields['company'])) {
            $locale[$cc]['company']['priority'] = 30;
        }
    }
    return $locale;
}, 20);

/**
 * A WooCommerce 11 a telefonmezőt a saját beállítása (woocommerce_checkout_phone_field) szerint a végén újra
 * felveszi: itt, a pénztár mezőinek végső listáján tesszük kötelezővé és a név mögé.
 */
add_filter('woocommerce_checkout_fields', function (array $f): array {
    if (isset($f['billing']['billing_phone'])) {
        $f['billing']['billing_phone']['required'] = true;
        $f['billing']['billing_phone']['priority'] = 25;
        $f['billing']['billing_phone']['class'] = ['form-row-wide'];
    }
    if (isset($f['billing']['billing_email'])) {
        $f['billing']['billing_email']['priority'] = 26;
        $f['billing']['billing_email']['class'] = ['form-row-wide'];
    }
    // A Számlázz.hu bővítmény adószám mezője a cégnév után (a saját mezőnk ilyenkor nincs, lásd fent).
    if (isset($f['billing']['wc_szamlazz_adoszam'])) {
        unset($f['billing']['billing_tax_number']);
        $f['billing']['wc_szamlazz_adoszam']['priority'] = 31;
        $f['billing']['wc_szamlazz_adoszam']['class'] = ['form-row-wide'];
        $f['billing']['wc_szamlazz_adoszam']['placeholder'] = '12345678-1-12';
        if (empty($f['billing']['wc_szamlazz_adoszam']['description'])) {
            $f['billing']['wc_szamlazz_adoszam']['description'] = 'Cégnek, ha a számlára kell.';
        }
    }
    uasort($f['billing'], fn($a, $b) => ($a['priority'] ?? 99) <=> ($b['priority'] ?? 99));
    return $f;
}, 999);
add_filter('pre_option_woocommerce_checkout_phone_field', fn() => 'required');

/**
 * Szállítási módok már a pénztár betöltésekor (az ügyfél jelezte, 2026-11-07: cím megadása után sem látott szállítást).
 * A WooCommerce a vendég országát alapból nem ismeri, ezért a szállítási sort csak a címmezők AJAX-frissítése után rajzolta
 * ki; ha az elmaradt, az összeg szállítás nélkül maradt. Csak Magyarországra szállítunk: a vendég alapból magyar címmel
 * számol, és a díjakhoz nem kell a teljes cím.
 */
add_filter('pre_option_woocommerce_default_customer_address', fn() => 'base');
add_filter('pre_option_woocommerce_shipping_cost_requires_address', fn() => 'no');
add_filter('default_checkout_billing_country', fn($c) => $c ?: 'HU');
add_filter('default_checkout_shipping_country', fn($c) => $c ?: 'HU');
add_action('woocommerce_before_checkout_form', function () {
    $cu = function_exists('WC') ? WC()->customer : null;
    if (!$cu) {
        return;
    }
    $changed = false;
    if (!$cu->get_billing_country()) {
        $cu->set_billing_country('HU');
        $changed = true;
    }
    if (!$cu->get_shipping_country()) {
        $cu->set_shipping_country('HU');
        $changed = true;
    }
    if ($changed) {
        $cu->save();
        WC()->cart->calculate_shipping();
        WC()->cart->calculate_totals();
    }
}, 1);

/**
 * A kosárban nincs szállítási mód választás (a pénztárban választják, ott a GLS-pont és a „csak az üzletben” szabály is):
 * a WooCommerce „szállítási díj a kosárban” kikapcsolása a már megadott címnél nem rejti el, ezért itt.
 */
add_filter('woocommerce_cart_ready_to_calc_shipping', function ($show) {
    return function_exists('is_cart') && is_cart() ? false : $show;
}, 99);
add_action('woocommerce_cart_totals_before_order_total', function () {
    if (WC()->cart && WC()->cart->needs_shipping()) {
        echo '<tr class="shipping-note"><th>Szállítás</th><td data-title="Szállítás">A pénztárban választod ki (személyes átvétel ingyenes).</td></tr>';
    }
});

/** A kosár / pénztár szállítási sora magyarul (a WooCommerce 11 „Shipment” felirata helyett). */
add_filter('woocommerce_shipping_package_name', fn($name, $i) => 'Szállítás', 10, 2);

add_action('woocommerce_after_checkout_validation', function ($data, WP_Error $errors) {
    $tax = trim((string) ($data['billing_tax_number'] ?? ''));
    if ($tax !== '' && !preg_match('/^\d{8}-?\d-?\d{2}$/', $tax)) {
        $errors->add('billing_tax_number', 'Az adószám formája: 12345678-1-12.');
    }
}, 10, 2);

add_action('woocommerce_checkout_create_order', function (WC_Order $order, array $data) {
    $tax = trim((string) ($data['billing_tax_number'] ?? ''));
    if ($tax === '') {
        return;
    }
    $order->update_meta_data('_billing_tax_number', $tax);
    $order->update_meta_data('_billing_wc_szamlazz_adoszam', $tax); // a Számlázz.hu bővítmény ezt olvassa
    $_POST['wc_szamlazz_adoszam'] = $tax; // a bővítmény saját mentése / NAV-ellenőrzése is lássa
    if ($order->get_customer_id()) {
        update_user_meta($order->get_customer_id(), 'wc_szamlazz_adoszam', $tax);
    }
}, 10, 2);

add_action('woocommerce_admin_order_data_after_billing_address', function (WC_Order $order) {
    $tax = (string) $order->get_meta('_billing_tax_number');
    if ($tax !== '') {
        echo '<p><strong>Adószám:</strong> ' . esc_html($tax) . '</p>';
    }
});

/** Az üres kosárból vissza a nyitóoldalra (a bolt-oldal a kategóriák listája). */
add_filter('woocommerce_return_to_shop_redirect', fn() => home_url('/'));
add_filter('woocommerce_return_to_shop_text', fn() => 'Vissza a boltba');

/** A fiók oldalon JS nélkül is a regisztráció mutatkozzon, ha onnan jönnek (?regisztracio=1). */
add_filter('body_class', function (array $c): array {
    if (!empty($_GET['regisztracio']) && function_exists('is_account_page') && is_account_page()) {
        $c[] = 'show-register';
    }
    return $c;
});

/** A termék „Kosárba” gombja után ne a WooCommerce saját „Kosár megtekintése” linkje jelenjen meg (a JS üzenetet ad). */
add_filter('woocommerce_product_add_to_cart_text', fn($t, $p) => $p && $p->is_in_stock() ? 'Kosárba' : 'Értesítést kérek!', 10, 2);

/**
 * Személyes átvétel: a pénztárban a cím és a nyitvatartás a szállítási mód alatt (a régi oldal szövegével).
 */
add_action('woocommerce_after_shipping_rate', function ($method) {
    if ($method->get_method_id() === 'local_pickup') {
        $c = (array) slugshop_site('contact', []);
        $hours = implode(' · ', array_map(fn($h) => implode(': ', (array) $h), (array) ($c['hours'] ?? [])));
        echo '<small class="method-note">' . esc_html(trim(($c['address'] ?? '') . ' · ' . $hours, ' ·')) . '</small>';
    }
});

/**
 * A WooCommerce a termék- és kategóriaoldalakhoz a saját sablonját töltené (archive-product.php, single-product.php),
 * így elmaradna az iu_theme fejléce, lábléce és a téma sablonja. Az iu_woocommerce mu-plugin nélkül ezt itt kell
 * visszairányítani a keretrendszer index.php-jára (iu-theme skill: márka-archívum buktató).
 */
add_filter('template_include', function ($template) {
    if (function_exists('is_woocommerce') && (is_woocommerce() || is_product_taxonomy())) {
        return get_template_directory() . '/index.php';
    }
    return $template;
}, 100);

/**
 * Csak az üzletben: a légfegyvert személyi igazolvánnyal, személyes átvétellel és helyszíni fizetéssel lehet megvenni
 * (az ügyfél szabálya). Ha a kosárban ilyen termék van, csak a személyes átvétel és a megadott fizetési mód(ok)
 * választhatók. Kategóriák és fizetési módok: Megjelenés → Slugshop → Adatok (alap: fx-fegyverek, ill. cod).
 */
function slugshop_shop_only_term_ids(): array
{
    static $ids = null;
    if ($ids === null) {
        $ids = [];
        foreach (array_filter(array_map('trim', explode(',', (string) slugshop_site('shopOnly.categories', 'fx-fegyverek')))) as $slug) {
            $t = get_term_by('slug', sanitize_title($slug), 'product_cat');
            if ($t) {
                $ids[] = (int) $t->term_id;
                $ids = array_merge($ids, array_map('intval', (array) get_term_children($t->term_id, 'product_cat')));
            }
        }
        $ids = array_values(array_unique($ids));
    }
    return $ids;
}

function slugshop_is_shop_only(int $product_id): bool
{
    $ids = slugshop_shop_only_term_ids();
    if (!$ids || !$product_id) {
        return false;
    }
    $parent = (int) wp_get_post_parent_id($product_id);
    $terms = wp_get_post_terms($parent ?: $product_id, 'product_cat', ['fields' => 'ids']);
    return is_array($terms) && (bool) array_intersect($ids, array_map('intval', $terms));
}

function slugshop_cart_has_shop_only(): bool
{
    if (!function_exists('WC') || !WC()->cart) {
        return false;
    }
    foreach (WC()->cart->get_cart() as $item) {
        if (slugshop_is_shop_only((int) ($item['product_id'] ?? 0))) {
            return true;
        }
    }
    return false;
}

function slugshop_shop_only_notice(): string
{
    return 'Légfegyvert csak az üzletünkben, személyes átvétellel és helyszíni fizetéssel vásárolhatsz (személyi igazolvány szükséges). Jászberény, ' . slugshop_site('contact.street', 'Megyeház u. 3–6.');
}

add_filter('woocommerce_package_rates', function ($rates) {
    if (!slugshop_cart_has_shop_only()) {
        return $rates;
    }
    $pickup = array_filter($rates, fn($r) => in_array($r->get_method_id(), ['local_pickup', 'pickup_location'], true));
    return $pickup ?: $rates; // ha nincs személyes átvétel beállítva, ne maradjon üresen a pénztár
}, 100);

add_filter('woocommerce_available_payment_gateways', function ($gateways) {
    if (is_admin() && !wp_doing_ajax()) {
        return $gateways;
    }
    if (!is_array($gateways) || !slugshop_cart_has_shop_only()) {
        return $gateways;
    }
    $allowed = array_filter(array_map('trim', explode(',', (string) slugshop_site('shopOnly.gateways', 'cod'))));
    return array_intersect_key($gateways, array_flip($allowed));
}, 100);

foreach (['woocommerce_before_cart', 'woocommerce_before_checkout_form'] as $hook) {
    add_action($hook, function () {
        if (slugshop_cart_has_shop_only() && function_exists('wc_print_notice')) {
            wc_print_notice(slugshop_shop_only_notice(), 'notice');
        }
    }, 5);
}

/**
 * Telefonszám a pénztárban (az ügyfél kérése, 2026-11-09: hibás számmal a GLS csomagpontos címkéje nem készült el –
 * „Invalid service parameter, Service PSD”). A magyar számot egységes alakra hozzuk (+36301234567: ezt a GLS elfogadja),
 * GLS-csomagpontnál és -automatánál mobilszám kell (a GLS SMS-ben értesít), hibás számnál magyar hibaüzenet.
 *
 * @return array{0: string, 1: string} [egységes szám vagy '', típus: mobile | landline | foreign | invalid]
 */
function slugshop_hu_phone(string $raw): array
{
    $raw = trim($raw);
    $d = preg_replace('/\D+/', '', $raw);
    if ($d === '') {
        return ['', 'invalid'];
    }
    if (str_starts_with($d, '0036')) {
        $d = substr($d, 2);
    } elseif (str_starts_with($d, '06')) {
        $d = '36' . substr($d, 2);
    } elseif (!str_starts_with($d, '36') && strlen($d) === 9 && preg_match('/^(20|30|31|50|70)/', $d)) {
        $d = '36' . $d; // „30 123 4567”
    } elseif (str_starts_with($raw, '+') && !str_starts_with($d, '36')) {
        return [strlen($d) >= 8 && strlen($d) <= 15 ? '+' . $d : '', strlen($d) >= 8 && strlen($d) <= 15 ? 'foreign' : 'invalid'];
    }
    if (!str_starts_with($d, '36')) {
        return ['', 'invalid'];
    }
    $n = substr($d, 2);
    if (preg_match('/^(20|30|31|50|70)\d{7}$/', $n)) {
        return ['+36' . $n, 'mobile'];
    }
    if (preg_match('/^(1\d{7}|(?!20|30|31|50|70)[2-9]\d{7})$/', $n)) { // a 20/30/31/50/70 mobil, nem körzetszám
        return ['+36' . $n, 'landline'];
    }
    return ['', 'invalid'];
}

function slugshop_is_gls_point(array $methods): bool
{
    foreach ($methods as $m) {
        if (str_starts_with((string) $m, 'gls_shipping_method_parcel_')) {
            return true;
        }
    }
    return false;
}

/** Egységes alak még a mentés előtt (a rendelésbe és a GLS-hez már így kerül). */
add_filter('woocommerce_checkout_posted_data', function (array $data): array {
    foreach (['billing_phone', 'shipping_phone'] as $k) {
        if (!empty($data[$k])) {
            [$norm] = slugshop_hu_phone((string) $data[$k]);
            if ($norm !== '') {
                $data[$k] = $norm;
            }
        }
    }
    return $data;
});

add_action('woocommerce_after_checkout_validation', function ($data, WP_Error $errors) {
    $example = 'pl. +36 30 123 4567';
    $billing = (string) ($data['billing_phone'] ?? '');
    [, $type] = slugshop_hu_phone($billing);
    if ($billing !== '' && $type === 'invalid') {
        $errors->add('billing_phone', 'A telefonszám nem teljes vagy nem jó formájú. Add meg körzet- vagy mobilszolgáltató-számmal együtt, ' . $example . ' (vezetékes: +36 57 123 456).');
        return;
    }
    if (!slugshop_is_gls_point((array) ($data['shipping_method'] ?? []))) {
        return;
    }
    $use_shipping = !empty($data['ship_to_different_address']) && !empty($data['shipping_phone']);
    [, $t] = slugshop_hu_phone($use_shipping ? (string) $data['shipping_phone'] : $billing);
    if ($t !== 'mobile') {
        $errors->add($use_shipping ? 'shipping_phone' : 'billing_phone', 'GLS-csomagpontra és -automatába csak magyar mobilszámmal tudunk küldeni, mert a GLS SMS-ben értesít, amikor a csomag megérkezett. Kérjük, adj meg mobilszámot (' . $example . '), vagy válassz másik szállítási módot.');
    }
}, 20, 2);

/** Segítség a mező alatt. */
add_filter('woocommerce_checkout_fields', function (array $f): array {
    if (isset($f['billing']['billing_phone'])) {
        $f['billing']['billing_phone']['description'] = 'GLS-csomagpontnál és -automatánál mobilszám kell (a GLS SMS-ben értesít).';
    }
    return $f;
}, 1000);
